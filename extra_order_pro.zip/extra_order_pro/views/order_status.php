<?php
if (!defined('ABSPATH')) {
    exit;
}

include_once(plugin_dir_path(__FILE__) . '../includes/order_status_form_submission.php');

global $wpdb;
$table_name_order_status = $wpdb->prefix . 'envoos_orders_extra_order_status';

$order_statuses = $wpdb->get_results("SELECT * FROM $table_name_order_status");

?>

<h2><?php esc_html_e('Order Status', 'woocommerce-order-extras'); ?></h2>
<button class="button ev-add-new-status-button" id="ev-add-new-order-status-button"><?php esc_html_e('Add New Order Status', 'woocommerce-order-extras'); ?></button>
<div id="ev-add-new-order-status-modal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close" id="ev-add-new-order-status-close">&times;</span>
        <form id="add-new-order-status-form" method="post">
            <?php wp_nonce_field('envoos_orders_extra_add_order_status', 'envoos_orders_extra_add_order_status_nonce'); ?>
            <input type="hidden" name="action" value="envoos_orders_extra_add_order_status">
            <label for="order-status-name"><?php esc_html_e('Order Status Name', 'woocommerce-order-extras'); ?>:</label>
            <input type="text" id="order-status-name" name="order_status_name" required>
            <input type="submit" class="button" value="<?php esc_html_e('Add Order Status', 'woocommerce-order-extras'); ?>">
        </form>
    </div>
</div>

<table class="wp-list-table widefat fixed striped" style="width: 95%; margin: 20px;">
    <thead>
        <tr>
            <th class="manage-column"><?php esc_html_e('ID', 'woocommerce-order-extras'); ?></th>
            <th class="manage-column"><?php esc_html_e('Order Status Name', 'woocommerce-order-extras'); ?></th>
            <th class="manage-column"><?php esc_html_e('Actions', 'woocommerce-order-extras'); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($order_statuses as $order_status) : ?>
            <tr>
                <td><?php echo esc_html($order_status->id); ?></td>
                <td>
                    <?php if (isset($_POST['action']) && $_POST['action'] === 'envoos_orders_extra_edit_order_status' && $_POST['order_status_id'] === $order_status->id) : ?>
                        <form method="post">
                            <?php wp_nonce_field('envoos_orders_extra_edit_order_status', 'envoos_orders_extra_edit_order_status_nonce'); ?>
                            <input type="hidden" name="action" value="envoos_orders_extra_edit_order_status">
                            <input type="hidden" name="order_status_id" value="<?php echo esc_attr($order_status->id); ?>">
                            <label for="edit-order-status-name"><?php esc_html_e('Edit Order Status Name', 'woocommerce-order-extras'); ?>:</label>
                            <input type="text" id="edit-order-status-name" name="order_status_name" value="<?php echo esc_attr($order_status->status_name); ?>" required>
                            <input name="btn_edit_order_status" type="submit" class="button" value="<?php esc_html_e('Save', 'woocommerce-order-extras'); ?>">
                        </form>
                    <?php else : ?>
                        <?php echo esc_html($order_status->status_name); ?>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if (isset($_POST['action']) && $_POST['action'] === 'envoos_orders_extra_edit_order_status' && $_POST['order_status_id'] === $order_status->id) : ?>
                        <form method="post" style="display: inline-block;">
                            <?php wp_nonce_field('cancel_edit_order_status', 'cancel_edit_order_status_nonce'); ?>
                            <input type="hidden" name="action" value="cancel_edit_order_status">
                            <input type="submit" class="button" value="<?php esc_html_e('Cancel', 'woocommerce-order-extras'); ?>">
                        </form>
                    <?php else : ?>
                        <form method="post" style="display: inline-block;">
                            <?php wp_nonce_field('envoos_orders_extra_edit_order_status', 'envoos_orders_extra_edit_order_status_nonce'); ?>
                            <input type="hidden" name="action" value="envoos_orders_extra_edit_order_status">
                            <input type="hidden" name="order_status_id" value="<?php echo esc_attr($order_status->id); ?>">
                            <input type="hidden" id="edit-order-status-name" name="order_status_name" value="<?php echo esc_attr($order_status->status_name); ?>" required>
                            <input type="submit" class="button" value="<?php esc_html_e('Edit', 'woocommerce-order-extras'); ?>">
                        </form>

                        <form method="post" style="display: inline-block; margin-left: 5px;">
                            <?php wp_nonce_field('envoos_orders_extra_delete_order_status', 'envoos_orders_extra_delete_order_status_nonce'); ?>
                            <input type="hidden" name="action" value="envoos_orders_extra_delete_order_status">
                            <input type="hidden" name="order_status_id" value="<?php echo esc_attr($order_status->id); ?>">
                            <input type="submit" class="button" value="<?php esc_html_e('Delete', 'woocommerce-order-extras'); ?>" onclick="return confirm('<?php echo esc_js(esc_html__('Are you sure you want to delete ' . $order_status->status_name . ' status?', 'woocommerce-order-extras')); ?>');">
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<script>
    const addNewModal = document.querySelector("#ev-add-new-order-status-modal");
    const addNewButton = document.querySelector("#ev-add-new-order-status-button");
    const closeButton = document.querySelector("#ev-add-new-order-status-close");

    addNewButton.addEventListener("click", () => addNewModal.style.display = "block");
    closeButton.addEventListener("click", () => addNewModal.style.display = "none");

    window.addEventListener("click", function(e) {
        if (e.target === addNewModal || e.target === closeButton) {
            addNewModal.style.display = "none";
        }
    });
</script>
