<?php
if (!defined('ABSPATH')) {
    exit;
}

function envoos_orders_extra_add_custom_tab($settings_tabs) {
    $settings_tabs['envoos_orders_extra_tab'] = __('Payment Extra', 'envoos-orders-extra');
    return $settings_tabs;
}

add_filter('woocommerce_settings_tabs_array', 'envoos_orders_extra_add_custom_tab', 50);

function envoos_orders_extra_get_payment_required_setting() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'envoos_orders_extra_order_payment';
    return $wpdb->get_results("SELECT * FROM $table_name");
}

function envoos_orders_extra_custom_tab_content() {
    $payment_is_required = envoos_orders_extra_get_payment_required_setting();
    if ($payment_is_required) {
        $payment_is_required = $payment_is_required[0]->status;
    }

    ?>
    <h2><?php esc_html_e('Payment Extra', 'envoos-orders-extra'); ?></h2>
    <?php
    woocommerce_admin_fields(envoos_orders_extra_payment_settings($payment_is_required));
}

add_action('woocommerce_settings_tabs_envoos_orders_extra_tab', 'envoos_orders_extra_custom_tab_content');

function envoos_orders_extra_payment_settings($payment_is_required) {
    $settings = array();
    $settings[] = array(
        'name'     => __('Require Payment Method', 'envoos-orders-extra'),
        'desc'     => __('Enable this to make the payment method required for each order.', 'envoos-orders-extra'),
        'id'       => 'envoos_orders_extra_require_payment',
        'type'     => 'checkbox',
        'css'      => 'min-width:300px;',
        'desc_tip' => true,
        'default'  => $payment_is_required,
    );

    return $settings;
}

function envoos_orders_extra_save_payment_settings() {
    $payment_required = isset($_POST['envoos_orders_extra_require_payment']) ? 1 : 0;

    global $wpdb;
    $table_name = $wpdb->prefix . 'envoos_orders_extra_order_payment';

    $existing_record = $wpdb->get_results("SELECT * FROM $table_name");

    if ($existing_record) {
        $wpdb->update(
            $table_name,
            array('status' => $payment_required),
            array('id' => $existing_record[0]->id),
            array('%d'),
            array('%d')
        );
    } else {
        $wpdb->insert(
            $table_name,
            array('status' => $payment_required),
            array('%d')
        );
    }

    woocommerce_update_options(envoos_orders_extra_payment_settings($payment_required));
}

add_action('woocommerce_update_options_envoos_orders_extra_tab', 'envoos_orders_extra_save_payment_settings');
