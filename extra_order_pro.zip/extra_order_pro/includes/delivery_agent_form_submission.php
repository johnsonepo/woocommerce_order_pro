<?php
if (!defined('ABSPATH')) {
    exit;
}

// Include WordPress functions
$wp_root_path = realpath(dirname(__FILE__) . '/../../../../');
include_once($wp_root_path . '/wp-load.php');

// Process POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = isset($_POST['action']) ? sanitize_text_field(wp_unslash($_POST['action'])) : '';

        switch ($action) {
            case 'envoos_orders_extra_add_agent':
                if (isset($_POST['agent_name'])) {
                    $agent_name = sanitize_text_field(wp_unslash($_POST['agent_name']));
                    envoos_orders_extra_add_agent($agent_name);
                }
                break;
            case 'envoos_orders_extra_edit_agent':
                if (isset($_POST['btn_edit'], $_POST['agent_id'], $_POST['agent_name'])) {
                    $agent_id = intval($_POST['agent_id']);
                    $agent_name = sanitize_text_field(wp_unslash($_POST['agent_name']));
                    envoos_orders_extra_edit_agent($agent_id, $agent_name);
                }
                break;
            case 'envoos_orders_extra_delete_agent':
                if (isset($_POST['agent_id'])) {
                    $agent_id = intval($_POST['agent_id']);
                    envoos_orders_extra_delete_agent($agent_id);
                }
                break;
            default:
                break;
        }
    }
}

// Add a delivery agent
function envoos_orders_extra_add_agent($agent_name) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'envoos_orders_extra_delivery_agents';
    $wpdb->insert(
        $table_name,
        array('agent_name' => $agent_name),
        array('%s')
    );
}

// Edit a delivery agent
function envoos_orders_extra_edit_agent($agent_id, $agent_name) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'envoos_orders_extra_delivery_agents';
    $wpdb->update(
        $table_name,
        array('agent_name' => $agent_name),
        array('id' => $agent_id),
        array('%s'),
        array('%d')
    );
}

// Delete a delivery agent
function envoos_orders_extra_delete_agent($agent_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'envoos_orders_extra_delivery_agents';
    $wpdb->delete(
        $table_name,
        array('id' => $agent_id),
        array('%d')
    );
}
