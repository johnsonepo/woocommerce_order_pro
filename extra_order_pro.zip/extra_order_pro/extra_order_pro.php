<?php
if (!defined('ABSPATH')) {
    exit;
}

/*
Plugin Name: Extra Order Pro
Description: This plugin adds extra fields to WooCommerce order such as order status and delivery agents.
Version: 1.1
Author: Johnson Epo (envoos)
Author URI: https://www.linkedin.com/in/envoos/
Plugin URI: https://wordpress.org/plugins/woocommerce-order-extras/
Text Domain: woocommerce-order-extras
Tags: woocommerce, orders, extras, delivery, status
License: GPL-3.0  
License URI: [GNU GPL v3.0](https://www.gnu.org/licenses/gpl-3.0.html)
*/

include_once(plugin_dir_path(__FILE__) . 'includes/envoos_orders_extra_database_manager.php');
include_once(plugin_dir_path(__FILE__) . 'includes/envoos_orders_extra_woocommerce_extra_fields.php');
include_once(plugin_dir_path(__FILE__) . 'includes/envoos_orders_extra_payment_method_setting.php');

function envoos_orders_extra_activation_hook() {
    if (!is_plugin_active('woocommerce/woocommerce.php')) {
        deactivate_plugins(plugin_basename(__FILE__));
    }

    EnvoosOrdersExtra_DatabaseManager::activate(); 
}

register_activation_hook(__FILE__, 'envoos_orders_extra_activation_hook');

function envoos_orders_extra_enqueue_styles_and_scripts() {
    // wp_enqueue_style('envoos-orders-extra-styles', plugin_dir_url(__FILE__) . 'css/style.css');
}
add_action('admin_enqueue_scripts', 'envoos_orders_extra_enqueue_styles_and_scripts');

function envoos_orders_extra_add_to_woocommerce_menu() {
    add_submenu_page(
        'woocommerce',
        esc_html__('Custom Order Status', 'woocommerce-order-extras'),
        esc_html__('Custom Order Status', 'woocommerce-order-extras'),
        'manage_options',
        'envoos_orders_extra_order_status',
        'envoos_orders_extra_display_order_status_tab'
    );

    add_submenu_page(
        'woocommerce',
        esc_html__('Delivery Agent', 'woocommerce-order-extras'),
        esc_html__('Delivery Agent', 'woocommerce-order-extras'),
        'manage_options',
        'envoos_orders_extra_delivery_agent',
        'envoos_orders_extra_display_delivery_agent_tab'
    );
}
add_action('admin_menu', 'envoos_orders_extra_add_to_woocommerce_menu');

function envoos_orders_extra_display_order_status_tab() {
    include(plugin_dir_path(__FILE__) . 'views/order_status.php');
}

function envoos_orders_extra_display_delivery_agent_tab() {
    include(plugin_dir_path(__FILE__) . 'views/delivery_agent.php');
}
